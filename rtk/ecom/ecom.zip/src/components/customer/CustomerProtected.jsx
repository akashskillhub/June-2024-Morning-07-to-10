import React from 'react'

const CustomerProtected = () => {
    return (
        <div>CustomerProtected</div>
    )
}

export default CustomerProtected