import React from 'react'

const AdminNavbar = () => {
    return (
        <div>AdminNavbar</div>
    )
}

export default AdminNavbar