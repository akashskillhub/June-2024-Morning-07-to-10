import React from 'react'

const AdminProtected = () => {
    return (
        <div>AdminProtected</div>
    )
}

export default AdminProtected