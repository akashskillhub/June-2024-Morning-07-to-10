import React from 'react'

const AdminProducts = () => {
    return (
        <div>AdminProducts</div>
    )
}

export default AdminProducts