import React from 'react'

const ErrorHandler = () => {
    return (
        <div>ErrorHandler</div>
    )
}

export default ErrorHandler