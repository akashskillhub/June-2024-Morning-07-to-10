import React from 'react'

const Parent = () => {
    return <>
        <div>Parent</div>
        <hr />
        <Child />
    </>

}

const Child = () => {
    return <>
        <div>child</div>
        <hr />
        <GrandChild />
    </>
}
const GrandChild = () => {
    return <>
        <div>Grand child</div>
    </>
}

export default Parent