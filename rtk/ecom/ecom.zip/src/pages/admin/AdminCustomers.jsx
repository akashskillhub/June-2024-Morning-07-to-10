import React from 'react'

const AdminCustomers = () => {
    return (
        <div>AdminCustomers</div>
    )
}

export default AdminCustomers