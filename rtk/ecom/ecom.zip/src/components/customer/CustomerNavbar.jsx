import React from 'react'

const CustomerNavbar = () => {
    return (
        <div>CustomerNavbar</div>
    )
}

export default CustomerNavbar